var import_app = require("firebase/app");
var import_database = require("firebase/database");
var import_openai = require("openai");
const configuration = new import_openai.Configuration({
  apiKey: process.env.OPENAI_API_KEY
});
const appSettings = {
  databaseURL: "https://prompt-playground-97436-default-rtdb.firebaseio.com/"
};
const openai = new import_openai.OpenAIApi(configuration);
const database = (0, import_database.getDatabase)(app);
const conversationInDb = (0, import_database.ref)(database);
const instructionObj = {
  role: "system",
  content: "You are a helpful assistant."
};
const handler = async (event) => {
  try {
    pushConversation(event.body);
    (0, import_database.get)(conversationInDb).then(async (snapshot) => {
      if (snapshot.exists()) {
        const conversationArr = Object.values(snapshot.val());
        conversationArr.unshift(instructionObj);
        const response = await openai.createChatCompletion({
          model: "gpt-3.5-turbo",
          messages: conversationArr,
          presence_penalty: 0,
          frequency_penalty: 0.3,
          max_tokens: 500,
          temperature: 0
        });
        (0, import_database.push)(conversationInDb, response.data.choices[0].message);
        return {
          statusCode: 200,
          body: JSON.stringify({ reply: response.data })
        };
      } else {
        return {
          statusCode: 404,
          body: JSON.stringify({ error: "Conversation does not exist" })
        };
      }
    });
  } catch (error) {
    return { statusCode: 500, body: error.toString() };
  }
};
function pushConversation(input) {
  (0, import_database.push)(conversationInDb, {
    role: "user",
    content: userInput.value
  });
}
module.exports = { handler };
